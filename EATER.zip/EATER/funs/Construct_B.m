function [B] = Construct_B(X)
m  = length(X);
n = size(X{1},2);
B={};
for k = 1:m
    B{k}=zeros(n,n);
    for i = 1:n
        for j = 1:n
            B{k}(i,j)=sum((X{k}(:,i)-X{k}(:,j)).^2);
        end
    end
end
end
