function y = rank_fun_derivative1(x,delta)

x = abs(x);
y  = delta*exp(delta^2)./((x+delta).^2+eps);
%y = delta./(delta+x).^2;
%y = (x+delta)./(delta*exp(x/delta).*(x+exp(-x/delta)).^2);
%y=delta./((x.^2+delta).*sqrt(x.^2+delta));
end
