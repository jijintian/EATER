clear;
clc
folder_now = pwd;
addpath([folder_now, '\funs']);
addpath([folder_now, '\dataset']);
dataname=["MSRCv1"];
%% ==================== Load Datatset and Normalization ===================
for it_name = 1:length(dataname)
   
    for missing_ratios = 0.1 :0.2 :0.5
        folds={};
        G={};
        load(strcat('dataset/',dataname(it_name),'.mat'));
        X = data;
        nV = length(X);
        N= size(X{1},2);
        for iter = 1:10 
        [ splitInd ] = splitDigitData(N,2,missing_ratios);

%         MissIndex ={};
%         for i = 1:nV
%             G_i{i}= zeros(N,floor(N*missing_ratios));
%             MissIndex{i} = find(splitInd(:,i)==0);
%             for j =1:length(MissIndex{i})
%                 G_i{i}(MissIndex{i}(j),j)=1;
%             end
%         end
%         G{iter}=G_i;
        folds{iter}=splitInd;
        end
      %  save('.\incomplete_DataIndex2\MissingDataIndex_' + dataname(it_name) + '_' + num2str(missing_ratios)+'.mat','folds')
      save('.\incomplete_DataIndex2\MissingDataIndex_' + dataname(it_name) + '_' + num2str(missing_ratios)+'.mat','folds')
    end
end