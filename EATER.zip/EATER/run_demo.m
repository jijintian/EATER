
clear;
clc

folder_now = pwd;
addpath([folder_now, '\funs']);
addpath([folder_now, '\dataset']);
addpath([folder_now, '\incomplete_DataIndex2']);
dataname=["NGs"];

%% ==================== Load Datatset and Normalization ===================
for it_name = 1:length(dataname)
    for missing_ratios = 0.1:0.2:0.5
        load(strcat('dataset/',dataname(it_name),'.mat'));
        load(strcat('incomplete_DataIndex2/','MissingDataIndex_',dataname(it_name),'_',num2str(missing_ratios),'.mat'));
        
        cls_num=length(unique(truelabel{1}));
        X=data';
        gt = truelabel{1};
        nV = length(X);
        N=size(X{1},2);
        N_miss = floor(size(X{1},2)*missing_ratios);
        
        for v=1:nV
            [X{v}]=NormalizeData(X{v});
        end
        
        %% ========================== Parameters Setting ==========================
        result=[];
        num = 0;
        record_num = 0;
        
        anc =[2*cls_num,3*cls_num,4*cls_num,5*cls_num,6*cls_num,7*cls_num];
        
        %% ============================ Optimization ==============================
        result_folds={};
        result =[];
        time=[];
        record_matrices={};
        for iter_folds = 1:10
            G={};
            MissIndex={};
            for i = 1:nV
                G{i}= zeros(N,N_miss);
                MissIndex{i} = find(folds{iter_folds}(:,i)==0);
                for j =1:length(MissIndex{i})
                    G{i}(MissIndex{i}(j),j)=1;
                end
            end
            X_miss=X;
            for v=1:nV
                X_miss{v}(:,find(folds{iter_folds}(:,v)==0)) = zeros(size(X{v},1),N_miss);
            end
            ii=0;
            max_val=0;
            for iter_alpha = -5:1:0
                for iter_gamma = -5:1:0
                    for iter_delta = -2:1:2
                        for iter_anchor =1:6
                            alpha = 10^(iter_alpha);
                            gamma = 10^(iter_gamma);
                            delta=10^(iter_delta);
                            anchor = anc(iter_anchor);
                            ii=ii+1;
                            time=[];
                            tic;
                            [y,U,Z,M,converge_Z,converge_Z_G] = Train_problem(N_miss,G,X_miss, cls_num, anchor,alpha,gamma,delta);
                            time_folds{iter_folds}(ii) = toc;
                            [result_flods{iter_folds}(ii,:),~]=  ClusteringMeasure(gt, y);
                            result_flods{iter_folds}
                            if result_flods{iter_folds}(ii,1) > max_val
                                max_val = result_flods{iter_folds}(ii,1);
                            end
                        end
                    end
                end
            end
             fprintf('max_value in %d folds  is %.4f\n',iter_folds,max_val);
             [~,max_index]=max(result_flods{iter_folds}(:,1));
            result(iter_folds,:) = result_flods{iter_folds}(max_index,:);
            time(iter_folds) = time_folds{iter_folds}(max_index);
        end
        result_mean = mean(result);
        result_std = std(result);
        time_mean = mean(time);
        time_std = std(time);
        
        save('.\result\result_'+dataname(it_name)+'_'+num2str(missing_ratios)+'.mat','time_std','time_mean',"result_mean","result_std","result")
    end
end
